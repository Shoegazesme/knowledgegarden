- > 此文档建立在 Logseq 上面，感谢 [@tiensonqin](https://twitter.com/tiensonqin) 提供了这么棒的双链笔记，得益于 [@pengx17](https://twitter.com/pengx17) 发布的 [Logseq Publish GitHub Action](https://pengx17.github.io/knowledge-garden/#/page/logseq%20publish%20github%20action)，可以非常方便的使用 Logseq 编写，使用 Git 发布它。
- # 样式
	- [[logseq dev theme]]
- # 配置
	- 请看 [[简悦 + Logseq + Github Page 无代码全自动化知识管理发布方案]]
- # 例子
  id:: 61fe1b3a-26e9-4ef6-a880-30cb013980f2
	- id:: 61fe1b3a-8356-4f20-b8f1-f5f4ed21ee7b
	  > 简悦自动导出到 Logseq 后发布到 Github Page 的例子。
		- [[践行极简理念，高效数字生活]]
		- [[哥斯拉]]
		- 更多例子 [Kenshin's Note](https://kenshin.wang/note)