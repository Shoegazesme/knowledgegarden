title::  泰坦巨兽终极图鉴

# MetaDate
        - Origin
            - [movie.douban.com](https://movie.douban.com/review/10214431/)
        - Date
            - 2022年02月02日 10:57:38
        - Desc
            - 《哥斯拉 2：怪兽之王》完整彩蛋与泰坦巨兽终极图鉴（哥斯拉 2：怪兽之王）影评
怪兽之王 在2014年上映的《哥斯拉》结尾，哥斯拉成为了拯救旧金山的英雄，在新闻中...

        - Tags
            - [[哥斯拉]]  
        - Backlinks
            -    > [[怪兽宇宙时间线大盘点]]

        - Reference
            - 

# Annoations

collapsed:: false  
    - #+BEGIN_QUOTE
        怪兽之王 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771666>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771666>)
collapsed:: false  
    - #+BEGIN_QUOTE
        氧气破坏者 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771668>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771668>)
collapsed:: false  
    - #+BEGIN_QUOTE
        军方为消灭巨兽所研发的武器名叫 “氧气破坏者”（Oxygen Destroyer），致敬了 1954 年原版《哥斯拉》中杀死初代哥斯拉的超级武器。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643798398133>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643798398133>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img9.doubanio.com/view/thing_review/l/public/p2907625.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643798404784>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643798404784>)
collapsed:: false  
    - #+BEGIN_QUOTE
        原版电影中氧气破坏者威力惊人，最终将哥斯拉化成一堆白骨。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643798402155>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643798402155>)
collapsed:: false  
    - #+BEGIN_QUOTE
        氧气破坏者还是 1995 年《哥斯拉 vs 戴斯特洛伊亚》中反派怪兽戴斯特洛伊亚的起源。

由于残留的氧气破坏者影响了生活在海底的远古微生物，令其异变成幼体，最终集合成强大的怪兽 “戴斯特洛伊亚”。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643798410557>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643798410557>)
collapsed:: false  
    - #+BEGIN_QUOTE
        芹泽博士 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771670>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771670>)
collapsed:: false  
    - #+BEGIN_QUOTE
        渡边谦饰演的芹泽猪四郎（Ishiro Serizawa）是帝王组织的主力科学家，这个角色的原型是 1954 年原版《哥斯拉》中的芹泽大助博士，最后用来消灭哥斯拉的氧气破坏者正是他研发的。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643798428497>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643798428497>)
collapsed:: false  
    - #+BEGIN_QUOTE
        芹泽猪四郎的名字也致敬了原版《哥斯拉》导演本多猪四郎

在原版《哥斯拉》中，芹泽博士为了不让氧气破坏者公诸于世而变成可怕的武器，选择销毁所有研究成果，并亲自潜入海中激活装置，最终与哥斯拉同归于尽。

本片中芹泽博士独自潜入底引爆核弹，让哥斯拉满血复活，同样以自我牺牲的方式完成英雄壮举。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643798449273>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643798449273>)
collapsed:: false  
    - #+BEGIN_QUOTE
        怪兽女王——摩斯拉 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 摩斯拉（ モスラ Mothra）不光是东宝第一个性别被定义为女性的怪物，还是第一只加入哥斯拉系列的怪兽。它的第一次登场是在一个名为 The Luminous Fairies and Mothra 的短篇小说中。同年东宝将这个故事改编成电影《摩斯拉》的剧本。正如之前《基多拉，三头怪物》中提到的那样，摩斯拉在系列中总是被描绘成一种善良和仁慈的生物，只有当它的信徒或是自己的卵受到伤害时才会主动造成破坏。绝大部分时间摩斯拉一直致力于保护地球和人类免受更大的伤害，这也是为何被称为 “怪兽女王” 的它深受女性观众的欢迎。在电影中摩斯拉是一个古老的蛾女神，被位于太平洋上一个用于核试验的小岛（婴儿岛）的原始部落当做守护神一般崇拜。它拥有强大的心灵感应能力，可以通过两个叫做 Shobijin（小美人）的女祭司交流。在第一部电影里当邪恶的企业家尼尔森掳走了两个女祭司以后，沉睡于卵中的摩斯拉被唤醒，并以一条毛虫的形态开始游向日本，期间还摧毁了一艘游轮。在到达了东京后，摩斯拉在东京塔废墟之上筑造了一个茧，破茧后进化成了成虫的完全体并继续寻找女祭司的下落。最终邪恶企业家在与警察的枪战中丧生，女祭司也得到了解救。影片最后，女祭司将摩斯拉吸引到机场跑道，摩斯拉接住二人后飞回了婴儿岛。
   > 
   > [[科普向：拉顿，摩斯拉，王者基多拉的小介绍]]
   
   > ### 出生最初在中村真一郎、福永武彦、堀田善卫合同创作的小说《发光妖精与摩斯拉》中出现，小说被改编为电影《[摩斯拉 (1961)](https://godzilla.fandom.com/zh/wiki/%E6%91%A9%E6%96%AF%E6%8B%89(1961))》，发光妖精则成为了[小美人](https://godzilla.fandom.com/zh/wiki/%E5%B0%8F%E7%BE%8E%E4%BA%BA)。### 命名以英语中的 “Mother”(妈妈) 和“Moth”(蛾)两词共同存在的 “Moth” 一节命名为 “Mothra”，以日语发音就成了“モスラ” 一词。### 设定结合**蛾**和**蝶**的特征而造出的虫类怪兽，是目前唯一一只能结茧的[东宝](https://godzilla.fandom.com/zh/wiki/%E6%9D%B1%E5%AF%B6)系怪兽，也是以怪兽蛋和以双胞胎形式出现次数最多的怪兽。和[哥吉拉](https://godzilla.fandom.com/zh/wiki/%E5%93%A5%E5%90%89%E6%8B%89)及[拉顿](https://godzilla.fandom.com/zh/wiki/%E6%8B%89%E9%A0%93)不同，未试过与人类正式敌对，反而是和平的使者、守护神。最为不同于其他怪兽的是它身边有[小美人](https://godzilla.fandom.com/zh/wiki/%E5%B0%8F%E7%BE%8E%E4%BA%BA)这个可以和人类互传信息角色。一直在幼虫身上没有作出什么外观变化，但在成虫身上的造型却不断变化。
   > 
   > [[摩斯拉]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771672>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771672>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img1.doubanio.com/view/thing_review/raw/public/p2915359.jpg) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643798484491>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643798484491>)
collapsed:: false  
    - #+BEGIN_QUOTE
        新版本摩斯拉的翅膀花纹采用哥斯拉的眼睛为设计形象，目的是为了对应彼此身为怪兽之王和怪兽女王的关系，也凸显了两者之间的联结。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643798506329>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643798506329>)
collapsed:: false  
    - #+BEGIN_QUOTE
        火之恶魔——拉顿 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 拉顿作为东宝的元老级怪兽之一，首次登场是 1956 年自己的独立怪兽电影《空中怪兽拉顿》（空の大怪獣ラドン，这也是东宝的第一部彩色怪兽电影）中。片中，拉顿是一种生活在地下深处的翼龙后裔，在暴露于辐射后发生突变成为巨兽。在原片中有一公一母两只拉顿，是一对相依相爱的配偶，栖息在日本最大的火山阿苏山中。然而由于阿苏山附近的北松采矿作业的影响，矿工们不光唤醒了恐怖的史前蜻蜓美加努隆（Meganulons），更是唤醒了在卵中沉睡了 2 亿年的拉顿，拉顿在破壳而出以后，由于辐射的影响体型迅速增大，变成了一只高 50 米，重 15000 吨，翼展超过百米的超级巨兽，并能以超音速飞行，而高速飞行所造成的强大气流更是将所经之处毁灭殆尽。
   > 
   > [[科普向：拉顿，摩斯拉，王者基多拉的小介绍]]
   
   > 拉顿是少数几只不会受到哥斯拉原子吐息伤害的怪物之一。在《基多拉，三头怪物》里哥斯拉几次用它的吐息对抗拉顿，但拉顿似乎完全没有受到吐息的影响。拉顿甚至在片中能够抗衡王者基多拉的重力光束。即使翅膀被击中几次也没有表现出任何疼痛或反应。
   > 
   > [[科普向：拉顿，摩斯拉，王者基多拉的小介绍]]
   
   > 拉顿最引人注目的特点是飞行速度，被称作天空之王的它可以毫不费力地战胜超音速飞机并保持惊人的灵活性。拉顿巨大的翅膀让它有能力在飞行时制造破坏性极强的强风，并在系列里摧毁了大量城市诸如东京和莫斯科。
   > 
   > [[科普向：拉顿，摩斯拉，王者基多拉的小介绍]]
   
   > 不同于其它怪物，拉顿拥有可以吸收附近的任何小动物以恢复健康和活力。
   > 
   > [[科普向：拉顿，摩斯拉，王者基多拉的小介绍]]
   
   > ### 出生最初在黑沼健创作的小说《空之大怪兽拉顿》中出现，小说被改编为同名电影《空之大怪兽拉顿》。### 命名无齿翼龙的日语名称 (プテラノドン) 以无齿翼龙的英语名称 (Pteranodon) 译音而成。拉顿的名称以无齿翼龙的日语名称 (プテラノドン) 抽出音节(プテ**ラ**ノ**ドン**) 而成为 “ラドン”。### 设定以超音速飞行，产生的能量震波具有高度破坏力，能破坏建筑物及军队。据柏木久一郎博士在《空之大怪兽拉顿》中讲解，是核子武器的能量震撼大地令拉顿的蛋被唤醒，但片中只交代了拉顿是翼龙的一种。造型以无齿翼龙为基础，冠饰缩短并分开为两个或三个，喙部也大幅缩短，颈部、腹部和腿部也设有甲片，腹部甲片上带刺，腿部加粗。有设定指出拉顿的脚底能喷出喷射气流，有加速飞行的作用。
   > 
   > [[拉顿]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771675>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771675>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img2.doubanio.com/view/thing_review/raw/public/p2914941.jpg) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643771030115>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643771030115>)
collapsed:: false  
    - #+BEGIN_QUOTE
        王者基多拉 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            -    [https://zh.wikipedia.org/wiki/王者基多拉](<https://zh.wikipedia.org/wiki/王者基多拉>)
   

        - Association
           - #+BEGIN_QUOTE
               > 作为 1964 年首次登场于哥斯拉系列的怪兽，它的出现可以说是标志了整个系列的重要转折点，因为即 1964 年的《基多拉：三头怪兽》之后，哥斯拉的形象从人类的对立面逐渐转变为了更为正面的地球守护者，可以说基多拉这个成功的反派形象奠定了之后系列中哥斯拉作为 “怪兽之王” 的地位。而票房的成功也让哥斯拉彻底成为了一个享誉全球的文化符号，可以说，没有二者的互相衬托，也就没有哥斯拉今天在怪兽电影里一哥的地位。
   > 
   > [[科普向：拉顿，摩斯拉，王者基多拉的小介绍]]
   
   > 王者基多拉最有名的能力莫过于从它三个嘴里吐出的金色闪电般的重力射线。与哥斯拉的原子吐息大致相似，能够引起大规模的爆炸。在《摩斯拉的重生 3》中，王者基多拉还能将三个重力射线组合成一次毁灭性的攻击
   > 
   > [[科普向：拉顿，摩斯拉，王者基多拉的小介绍]]
   
   > 王者基多拉可以从翅膀中释放闪电（这一招在哥斯拉 2：怪兽之王中也可以见到）
   > 
   > [[科普向：拉顿，摩斯拉，王者基多拉的小介绍]]
   
   > ### 出生因为[哥吉拉](https://godzilla.fandom.com/zh/wiki/%E5%93%A5%E5%90%89%E6%8B%89)、[摩斯拉](https://godzilla.fandom.com/zh/wiki/%E6%91%A9%E6%96%AF%E6%8B%89)和[拉顿](https://godzilla.fandom.com/zh/wiki/%E6%8B%89%E9%A0%93)转型为 “正义英雄” 的关系，必须出现一个反派。因为 “外星人入侵地球” 的桥段，便创造出国王基多拉。### 命名“King”是 “国王” 的意思，“Ghidorah”只是一串音标 (可能当作外星语言)，加在一起便是“King Ghidorah”，日语音译为“キングギドラ”。另外在《哥吉拉 摩斯拉 国王基多拉 大怪兽总攻击》中出现的汉字名称只是直接把“ギドラ” 直接转换成汉字“魏怒罗”。### 设定受 1956 年的苏联电影《Ilya Muromets》(1959 年 3 月才在[日本](https://godzilla.fandom.com/zh/wiki/%E6%97%A5%E6%9C%AC)上映) 中出现的三头火龙 “**Zmey Gorynych**”、1963 年的美国电影《Jason and the Argonauts》中出现的七头蛇 “**Hydra**” 和 1959 年的[日本](https://godzilla.fandom.com/zh/wiki/%E6%97%A5%E6%9C%AC)电影《日本诞生》中出现的九头蛇 “**八岐大蛇**” 所影响，再加以设计的怪兽。原型的设计者为利光贞三。主要在[昭和代哥吉拉电影系列](https://godzilla.fandom.com/zh/wiki/Category:%E6%98%AD%E5%92%8C%E4%BB%A3%E5%93%A5%E5%90%89%E6%8B%89%E9%9B%BB%E5%BD%B1%E7%B3%BB%E5%88%97)中设定为具侵略性的凶残宇宙怪兽，在五千年前把金星的高度文明于三日内毁灭，后来又成为了外星人时常操纵的怪兽，多次攻击地球。外型为三头、两尾、背有巨大翅膀、无手臂，全身为金色鳞甲，头部为额有三日月形的龙头。叫声为电子音效所造，在平成代开始与拿顿的叫声混音。
   > 
   > [[国王基多拉]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771677>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771677>)
collapsed:: false  
    - #+BEGIN_QUOTE
        哥斯拉之最 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771678>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771678>)
collapsed:: false  
    - #+BEGIN_QUOTE
        红莲哥斯拉 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771680>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771680>)
collapsed:: false  
    - #+BEGIN_QUOTE
        影片中，哥斯拉补充核能并吸收摩斯拉的能量粒子后，身体大面积变成红色，这个形象致敬了 1995 年《哥斯拉 vs 戴斯特洛伊亚》中登场的红莲哥斯拉。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643798543166>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643798543166>)
collapsed:: false  
    - #+BEGIN_QUOTE
        泰坦巨兽 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771682>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771682>)
collapsed:: false  
    - #+BEGIN_QUOTE
        金刚（Kong）：全世界最具知名度的怪兽之一，首次登场于 1933 年美国同名电影《金刚》。在 2017 年《金刚：骷髅岛》加入怪兽电影宇宙，未来与哥斯拉将有争霸战。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            -    [https://movie.douban.com/review/8430951/](<https://movie.douban.com/review/8430951/>)
   [https://movie.douban.com/review/8431649/](<https://movie.douban.com/review/8431649/>)
   

        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770856355>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770856355>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img9.doubanio.com/view/thing_review/l/public/p2912655.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770870644>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770870644>)
collapsed:: false  
    - #+BEGIN_QUOTE
        穆托（MUTO）：全名为 Massive Unidentified Terrestrial Organism（未确认巨大陆生生命体），是以放射能源为食的古代巨怪。 穆托是怪兽电影宇宙的原创怪兽，在 2014 年《哥斯拉》中首次登场。前作中哥斯拉已杀死雌雄两只穆托，而在本片中出场的是一只全新的穆托。（可能来自外传漫画中穆透至尊留下的卵） 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770860631>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770860631>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img1.doubanio.com/view/thing_review/l/public/p2915429.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770873495>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770873495>)
collapsed:: false  
    - #+BEGIN_QUOTE
        *   斯库拉（Scylla）：原型是希腊神话中专吃水手的女海妖，拥有六颗头和十二条腿。 影片中斯库拉的形象为长着触须和节肢长腿的泰坦巨兽。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770865552>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770865552>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img2.doubanio.com/view/thing_review/l/public/p2915772.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770890380>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770890380>)
collapsed:: false  
    - #+BEGIN_QUOTE
        玛士撒拉（Methuselah）：出自《圣经旧约》中亚当与夏娃的后代，也是圣经记录中最长寿的人。他的孙子就是建造方舟保护了地球各种动物的诺亚。 影片里在深山中崛起的巨兽名为玛士撒拉。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770902412>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770902412>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img9.doubanio.com/view/thing_review/l/public/p2912654.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770908055>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770908055>)
collapsed:: false  
    - #+BEGIN_QUOTE
        贝希摩斯（Behemoth）：《圣经》中出现的怪物，与利维坦一样在上帝创世纪第六天用粘土所创造。从词源上来讲，"Behemoth" 可以表示所有巨大、笨重和未知的动物。 影片中看起来像猛犸象的巨兽就叫做贝希摩斯。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770910965>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770910965>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img3.doubanio.com/view/thing_review/l/public/p2915480.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770916505>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770916505>)
collapsed:: false  
    - #+BEGIN_QUOTE
        *   利维坦（Leviathan）：《圣经》中上帝在创世第六天用粘土创造的怪物，能引起巨大的海啸和旋涡，是海中怪物的霸主。影片中利维坦是帝王组织在尼斯湖一带发现的巨型水怪。
*   亚巴顿（Abaddon）：《新约圣经 · 启示录》中掌管无底坑的使者的名字，代表毁灭之地，所到之处必将毁灭。
*   魔克拉 - 姆边贝（Mokele-Mbembe），栖息在刚果河流域沼泽的巨大神秘生物。
*   巴风特（Baphomet）：基督教中有名的羊头恶魔。
*   提亚马特（Tiamat）：巴比伦神话中创造世界的神龙，名字的含义是 “母亲”。
*   萨尔贡（Sargon）：历史人物，阿卡德王国的开创者，古代近东地区最伟大的君主之一。
*   提丰（Typhoon）：希腊神话中的恶魔泰坦。
*   本耶普（Bunyip）：澳大利亚传说中的神秘生物。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770931594>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770931594>)
collapsed:: false  
    - #+BEGIN_QUOTE
        哥斯拉大战金刚 
        #+END_QUOTE
        collapsed:: true  
        - Note
            - #+BEGIN_QUOTE
               
              #+END_QUOTE
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771686>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2293?title=泰坦巨兽终极图鉴#id=1643770771686>)
