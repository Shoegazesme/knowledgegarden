title::  拉顿

# MetaDate
        - Origin
            - [godzilla.fandom.com](https://godzilla.fandom.com/zh/wiki/%E6%8B%89%E9%A0%93)
        - Date
            - 2022年02月02日 11:26:40
        - Desc
            - 和哥吉拉、摩斯拉合稱為東寶三大怪獸，但受歡迎度不及前兩者，在電影中的出場次數也不高。
        - Tags
            - [[哥斯拉/拉顿]]  
        - Backlinks
            - 
        - Reference
            - 

# Annoations

collapsed:: false  
    - #+BEGIN_QUOTE
        ### 出生

最初在黑沼健创作的小说《空之大怪兽拉顿》中出现，小说被改编为同名电影《空之大怪兽拉顿》。

### 命名

无齿翼龙的日语名称 (プテラノドン) 以无齿翼龙的英语名称 (Pteranodon) 译音而成。拉顿的名称以无齿翼龙的日语名称 (プテラノドン) 抽出音节(プテ**ラ**ノ**ドン**) 而成为 “ラドン”。

### 设定

以超音速飞行，产生的能量震波具有高度破坏力，能破坏建筑物及军队。据柏木久一郎博士在《空之大怪兽拉顿》中讲解，是核子武器的能量震撼大地令拉顿的蛋被唤醒，但片中只交代了拉顿是翼龙的一种。

造型以无齿翼龙为基础，冠饰缩短并分开为两个或三个，喙部也大幅缩短，颈部、腹部和腿部也设有甲片，腹部甲片上带刺，腿部加粗。

有设定指出拉顿的脚底能喷出喷射气流，有加速飞行的作用。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 火之恶魔——拉顿
   > 
   > [[泰坦巨兽终极图鉴]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2295?title=拉顿#id=1643772400496>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2295?title=拉顿#id=1643772400496>)
