title::  科普向：拉顿，摩斯拉，王者基多拉的小介绍

# MetaDate
        - Origin
            - [movie.douban.com](https://movie.douban.com/review/10203351/)
        - Date
            - 2022年02月02日 11:03:11
        - Desc
            - 拉顿 拉顿（ ラドン Rodan） 在影片中的形象是只巨大的无齿翼龙（Pteranodon），它...
        - Tags
            - [[哥斯拉]]  
        - Backlinks
            - 
        - Reference
            - 

# Annoations

collapsed:: false  
    - #+BEGIN_QUOTE
        拉顿 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771210666>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771210666>)
collapsed:: false  
    - #+BEGIN_QUOTE
        拉顿作为东宝的元老级怪兽之一，首次登场是 1956 年自己的独立怪兽电影《空中怪兽拉顿》（空の大怪獣ラドン，这也是东宝的第一部彩色怪兽电影）中。片中，拉顿是一种生活在地下深处的翼龙后裔，在暴露于辐射后发生突变成为巨兽。在原片中有一公一母两只拉顿，是一对相依相爱的配偶，栖息在日本最大的火山阿苏山中。然而由于阿苏山附近的北松采矿作业的影响，矿工们不光唤醒了恐怖的史前蜻蜓美加努隆（Meganulons），更是唤醒了在卵中沉睡了 2 亿年的拉顿，拉顿在破壳而出以后，由于辐射的影响体型迅速增大，变成了一只高 50 米，重 15000 吨，翼展超过百米的超级巨兽，并能以超音速飞行，而高速飞行所造成的强大气流更是将所经之处毁灭殆尽。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 火之恶魔——拉顿
   > 
   > [[泰坦巨兽终极图鉴]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771001443>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771001443>)
collapsed:: false  
    - #+BEGIN_QUOTE
        拉顿是少数几只不会受到哥斯拉原子吐息伤害的怪物之一。在《基多拉，三头怪物》里哥斯拉几次用它的吐息对抗拉顿，但拉顿似乎完全没有受到吐息的影响。拉顿甚至在片中能够抗衡王者基多拉的重力光束。即使翅膀被击中几次也没有表现出任何疼痛或反应。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 火之恶魔——拉顿
   > 
   > [[泰坦巨兽终极图鉴]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771114332>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771114332>)
collapsed:: false  
    - #+BEGIN_QUOTE
        拉顿最引人注目的特点是飞行速度，被称作天空之王的它可以毫不费力地战胜超音速飞机并保持惊人的灵活性。拉顿巨大的翅膀让它有能力在飞行时制造破坏性极强的强风，并在系列里摧毁了大量城市诸如东京和莫斯科。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 火之恶魔——拉顿
   > 
   > [[泰坦巨兽终极图鉴]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771118272>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771118272>)
collapsed:: false  
    - #+BEGIN_QUOTE
        不同于其它怪物，拉顿拥有可以吸收附近的任何小动物以恢复健康和活力。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 火之恶魔——拉顿
   > 
   > [[泰坦巨兽终极图鉴]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771124975>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771124975>)
collapsed:: false  
    - #+BEGIN_QUOTE
        在拉顿变为火拉顿以后习得的能力，可以从嘴里发射放射性热束攻击敌人，类似于哥斯拉的原子吐息。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771135367>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771135367>)
collapsed:: false  
    - #+BEGIN_QUOTE
        摩斯拉 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771201904>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771201904>)
collapsed:: false  
    - #+BEGIN_QUOTE
        摩斯拉（ モスラ Mothra）不光是东宝第一个性别被定义为女性的怪物，还是第一只加入哥斯拉系列的怪兽。它的第一次登场是在一个名为 The Luminous Fairies and Mothra 的短篇小说中。同年东宝将这个故事改编成电影《摩斯拉》的剧本。正如之前《基多拉，三头怪物》中提到的那样，摩斯拉在系列中总是被描绘成一种善良和仁慈的生物，只有当它的信徒或是自己的卵受到伤害时才会主动造成破坏。绝大部分时间摩斯拉一直致力于保护地球和人类免受更大的伤害，这也是为何被称为 “怪兽女王” 的它深受女性观众的欢迎。在电影中摩斯拉是一个古老的蛾女神，被位于太平洋上一个用于核试验的小岛（婴儿岛）的原始部落当做守护神一般崇拜。它拥有强大的心灵感应能力，可以通过两个叫做 Shobijin（小美人）的女祭司交流。在第一部电影里当邪恶的企业家尼尔森掳走了两个女祭司以后，沉睡于卵中的摩斯拉被唤醒，并以一条毛虫的形态开始游向日本，期间还摧毁了一艘游轮。在到达了东京后，摩斯拉在东京塔废墟之上筑造了一个茧，破茧后进化成了成虫的完全体并继续寻找女祭司的下落。最终邪恶企业家在与警察的枪战中丧生，女祭司也得到了解救。影片最后，女祭司将摩斯拉吸引到机场跑道，摩斯拉接住二人后飞回了婴儿岛。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 怪兽女王——摩斯拉
   > 
   > [[泰坦巨兽终极图鉴]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771196544>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771196544>)
collapsed:: false  
    - #+BEGIN_QUOTE
        王者基多拉 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771379338>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771379338>)
collapsed:: false  
    - #+BEGIN_QUOTE
        作为 1964 年首次登场于哥斯拉系列的怪兽，它的出现可以说是标志了整个系列的重要转折点，因为即 1964 年的《基多拉：三头怪兽》之后，哥斯拉的形象从人类的对立面逐渐转变为了更为正面的地球守护者，可以说基多拉这个成功的反派形象奠定了之后系列中哥斯拉作为 “怪兽之王” 的地位。而票房的成功也让哥斯拉彻底成为了一个享誉全球的文化符号，可以说，没有二者的互相衬托，也就没有哥斯拉今天在怪兽电影里一哥的地位。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 王者基多拉
   > 
   > [[泰坦巨兽终极图鉴]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771416107>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771416107>)
collapsed:: false  
    - #+BEGIN_QUOTE
        王者基多拉最有名的能力莫过于从它三个嘴里吐出的金色闪电般的重力射线。与哥斯拉的原子吐息大致相似，能够引起大规模的爆炸。在《摩斯拉的重生 3》中，王者基多拉还能将三个重力射线组合成一次毁灭性的攻击 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 王者基多拉
   > 
   > [[泰坦巨兽终极图鉴]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771678209>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771678209>)
collapsed:: false  
    - #+BEGIN_QUOTE
        王者基多拉可以从翅膀中释放闪电（这一招在哥斯拉 2：怪兽之王中也可以见到） 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 王者基多拉
   > 
   > [[泰坦巨兽终极图鉴]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771686606>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2294?title=科普向：拉顿，摩斯拉，王者基多拉的小介绍#id=1643771686606>)
