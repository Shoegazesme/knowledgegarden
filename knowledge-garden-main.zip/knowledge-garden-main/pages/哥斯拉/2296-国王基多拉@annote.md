title::  国王基多拉

# MetaDate
        - Origin
            - [godzilla.fandom.com](https://godzilla.fandom.com/zh/wiki/%E5%9C%8B%E7%8E%8B%E5%9F%BA%E5%A4%9A%E6%8B%89)
        - Date
            - 2022年02月02日 11:27:25
        - Desc
            - 哥吉拉電影系列中最具知名度反派怪獸之一，也是哥吉拉電影系列中首隻宇宙怪獸，被譽為「系列之中最強的反派」、「哥吉拉最大的對手」，但是在昭和代哥吉拉電影系列、平成代哥吉拉電影系列、平成代摩斯拉電影系列和新世代哥吉拉電影系列中的角色設定也不一樣。
        - Tags
            - [[哥斯拉/国王基多拉]]  
        - Backlinks
            - 
        - Reference
            - 

# Annoations

collapsed:: false  
    - #+BEGIN_QUOTE
        ### 出生

因为[哥吉拉](https://godzilla.fandom.com/zh/wiki/%E5%93%A5%E5%90%89%E6%8B%89)、[摩斯拉](https://godzilla.fandom.com/zh/wiki/%E6%91%A9%E6%96%AF%E6%8B%89)和[拉顿](https://godzilla.fandom.com/zh/wiki/%E6%8B%89%E9%A0%93)转型为 “正义英雄” 的关系，必须出现一个反派。因为 “外星人入侵地球” 的桥段，便创造出国王基多拉。

### 命名

“King”是 “国王” 的意思，“Ghidorah”只是一串音标 (可能当作外星语言)，加在一起便是“King Ghidorah”，日语音译为“キングギドラ”。另外在《哥吉拉 摩斯拉 国王基多拉 大怪兽总攻击》中出现的汉字名称只是直接把“ギドラ” 直接转换成汉字“魏怒罗”。

### 设定

受 1956 年的苏联电影《Ilya Muromets》(1959 年 3 月才在[日本](https://godzilla.fandom.com/zh/wiki/%E6%97%A5%E6%9C%AC)上映) 中出现的三头火龙 “**Zmey Gorynych**”、1963 年的美国电影《Jason and the Argonauts》中出现的七头蛇 “**Hydra**” 和 1959 年的[日本](https://godzilla.fandom.com/zh/wiki/%E6%97%A5%E6%9C%AC)电影《日本诞生》中出现的九头蛇 “**八岐大蛇**” 所影响，再加以设计的怪兽。原型的设计者为利光贞三。

主要在[昭和代哥吉拉电影系列](https://godzilla.fandom.com/zh/wiki/Category:%E6%98%AD%E5%92%8C%E4%BB%A3%E5%93%A5%E5%90%89%E6%8B%89%E9%9B%BB%E5%BD%B1%E7%B3%BB%E5%88%97)中设定为具侵略性的凶残宇宙怪兽，在五千年前把金星的高度文明于三日内毁灭，后来又成为了外星人时常操纵的怪兽，多次攻击地球。

外型为三头、两尾、背有巨大翅膀、无手臂，全身为金色鳞甲，头部为额有三日月形的龙头。叫声为电子音效所造，在平成代开始与拿顿的叫声混音。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 王者基多拉
   > 
   > [[泰坦巨兽终极图鉴]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2296?title=国王基多拉#id=1643772463360>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2296?title=国王基多拉#id=1643772463360>)
