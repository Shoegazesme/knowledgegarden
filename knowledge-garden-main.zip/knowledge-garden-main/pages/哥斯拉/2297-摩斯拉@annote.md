title::  摩斯拉

# MetaDate
        - Origin
            - [godzilla.fandom.com](https://godzilla.fandom.com/zh/wiki/%E6%91%A9%E6%96%AF%E6%8B%89)
        - Date
            - 2022年02月02日 11:28:20
        - Desc
            - 和哥吉拉、拉頓合稱為東寶三大怪獸，被稱為怪獸之后。
        - Tags
            - [[哥斯拉/摩斯拉]]  
        - Backlinks
            - 
        - Reference
            - 

# Annoations

collapsed:: false  
    - #+BEGIN_QUOTE
        ### 出生

最初在中村真一郎、福永武彦、堀田善卫合同创作的小说《发光妖精与摩斯拉》中出现，小说被改编为电影《[摩斯拉 (1961)](https://godzilla.fandom.com/zh/wiki/%E6%91%A9%E6%96%AF%E6%8B%89(1961))》，发光妖精则成为了[小美人](https://godzilla.fandom.com/zh/wiki/%E5%B0%8F%E7%BE%8E%E4%BA%BA)。

### 命名

以英语中的 “Mother”(妈妈) 和“Moth”(蛾)两词共同存在的 “Moth” 一节命名为 “Mothra”，以日语发音就成了“モスラ” 一词。

### 设定

结合**蛾**和**蝶**的特征而造出的虫类怪兽，是目前唯一一只能结茧的[东宝](https://godzilla.fandom.com/zh/wiki/%E6%9D%B1%E5%AF%B6)系怪兽，也是以怪兽蛋和以双胞胎形式出现次数最多的怪兽。

和[哥吉拉](https://godzilla.fandom.com/zh/wiki/%E5%93%A5%E5%90%89%E6%8B%89)及[拉顿](https://godzilla.fandom.com/zh/wiki/%E6%8B%89%E9%A0%93)不同，未试过与人类正式敌对，反而是和平的使者、守护神。最为不同于其他怪兽的是它身边有[小美人](https://godzilla.fandom.com/zh/wiki/%E5%B0%8F%E7%BE%8E%E4%BA%BA)这个可以和人类互传信息角色。

一直在幼虫身上没有作出什么外观变化，但在成虫身上的造型却不断变化。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
               > 怪兽女王——摩斯拉
   > 
   > [[泰坦巨兽终极图鉴]]

             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2297?title=摩斯拉#id=1643772500700>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2297?title=摩斯拉#id=1643772500700>)
