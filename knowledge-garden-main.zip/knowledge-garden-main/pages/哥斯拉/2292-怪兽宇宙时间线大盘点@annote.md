title::  怪兽宇宙时间线大盘点

# MetaDate
        - Origin
            - [movie.douban.com](https://movie.douban.com/review/13305009/?dt_dapp=1)
        - Date
            - 2022年02月01日 18:51:08
        - Desc
            - yo，回首2017年《金刚：骷髅岛》上映时，哥斯拉在片尾彩蛋出现，怪兽宇宙版图扩张...
        - Tags
            - [[哥斯拉]]  
        - Backlinks
            -    > [[泰坦巨兽终极图鉴]]

        - Reference
            - 

# Annoations

collapsed:: false  
    - #+BEGIN_QUOTE
        根据考古学家对化石的研究，泰坦巨兽早在恐龙时代就已经存在，在 2.5 亿年前左右，一颗彗星撞击了地球，一些泰坦巨兽则钻入地心世界进入长时间的休眠。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770298571>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770298571>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img9.doubanio.com/view/thing_review/l/public/p5729306.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770302572>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770302572>)
collapsed:: false  
    - #+BEGIN_QUOTE
        大约在公元前 50000 年的时候，亚特兰蒂斯国就在岩石图腾记载过，他们族人和哥斯拉有着神秘的共存关系，亚特兰蒂斯族人把哥斯拉奉为神明一般的存在。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770313339>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770313339>)
collapsed:: false  
    - #+BEGIN_QUOTE
        在公元前的 12000 年的时候，中国云南的神庙壁画中，有着摩斯拉的踪迹，摩斯拉同样被当时的人类供奉为吉祥的象征，壁画中的摩斯拉，还有着它完整从卵到幼虫到蛹再到蜕变成摩斯拉的每个形态示意图。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770316367>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770316367>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img1.doubanio.com/view/thing_review/l/public/p5729308.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770319544>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770319544>)
collapsed:: false  
    - #+BEGIN_QUOTE
        在公元前 1100 年，在菲律宾有一只哥斯拉的同类名叫达贡，和最高完全态的至尊穆托有过一战，达贡战败，之后穆托产把卵寄生达贡体内，这也是《哥斯拉》的事件开端。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770344710>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770344710>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img1.doubanio.com/view/thing_review/l/public/p5729307.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770346713>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770346713>)
collapsed:: false  
    - #+BEGIN_QUOTE
        1943 年劳顿号事件，该事件是美国的劳顿号战舰被不明巨大生物袭击导致搁浅，全员只有威廉. 比尔. 兰达幸存，之后美方掩盖了该事件。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770361104>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770361104>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img3.doubanio.com/view/thing_review/l/public/p5729310.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770363633>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770363633>)
collapsed:: false  
    - #+BEGIN_QUOTE
        也正因为这些怪事接二连三的出现，当时的杜鲁门总统后来在 1946 年的时候，秘密成立的帝王（君主）组织，帝王组织的座右铭是：“疯狂背后隐藏着真相”，他们的使命和宗旨，是发现并研究巨兽，组建防御保护人类。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770432874>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770432874>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img2.doubanio.com/view/thing_review/l/public/p5729313.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770439131>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770439131>)
collapsed:: false  
    - #+BEGIN_QUOTE
        此前劳顿号事件幸存的比尔兰达，就是该组织的初代成员之一，老芹泽也加入其该组织。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770455643>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643770455643>)
collapsed:: false  
    - #+BEGIN_QUOTE
        时间转瞬即逝，让我们去到 1973 年，也就是按照正序时间开始讲述《金刚：骷髅岛》的故事了。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782369792>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782369792>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img1.doubanio.com/view/thing_review/l/public/p5729317.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782379941>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782379941>)
collapsed:: false  
    - #+BEGIN_QUOTE
        这一炸就直接把金刚给炸了出来，此时的金刚大概有 100 英尺约 30 米高，年龄大概在青少年时期。

不过到了《哥斯拉大战金刚》的电影中，金刚那时已经是 102 米高的巨兽正直壮年，所以也和哥斯拉身高差不多。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782411914>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782411914>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img1.doubanio.com/view/thing_review/l/public/p5729319.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782422348>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782422348>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img2.doubanio.com/view/thing_review/l/public/p5729322.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782425039>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782425039>)
collapsed:: false  
    - #+BEGIN_QUOTE
        我们结合漫画，来揭开金刚的身世秘密，金刚原本是一个族群，自古以来就和来自地底下的骷髅爬虫是死敌，早很多年前，包括金刚父母在内的金刚族群，和骷髅爬虫群有一场厮杀大战，在那场撕斗中，金刚出生。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782500364>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782500364>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img9.doubanio.com/view/thing_review/l/public/p5729326.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782508970>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782508970>)
collapsed:: false  
    - #+BEGIN_QUOTE
        幼小的金刚目睹了父母在这场战斗中丧生，他后来得以幸存下来，成为仅剩的一只金刚，在后面探险队看到的巨型遗骸，就是金刚的父母。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782512487>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782512487>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img9.doubanio.com/view/thing_review/l/public/p5729325.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782514907>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782514907>)
collapsed:: false  
    - #+BEGIN_QUOTE
        在影片结尾彩蛋中，康拉德和梅森韦弗被软禁起来，休斯顿. 布鲁克和孙琳过来请求他们加入帝王组织，并向他们透露了更多帝王组织关于泰坦巨兽的发现。

比如哥斯拉，摩斯拉，基多拉，拉顿等，但骷髅岛事件，等于是现代人类亲眼验证了巨兽的存在。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782529889>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782529889>)
collapsed:: false  
    - #+BEGIN_QUOTE
        之后时间就来到了 2014 年上映的《哥斯拉》。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782735782>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782735782>)
collapsed:: false  
    - #+BEGIN_QUOTE
        影片开始前面也已经交代了，他们在菲律宾发现了哥斯拉同类达贡的化石遗骸，同时还有两颗孢子。

其中一颗已经孵化，前进的方向是日本，另一颗还未来得及孵化的被秘密带到了美国内华达州。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782744084>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782744084>)
collapsed:: false  
    - #+BEGIN_QUOTE
        孢子破茧而出了穆托，它振起双翅飞离日本 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782916900>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782916900>)
collapsed:: false  
    - #+BEGIN_QUOTE
        诞生出来的穆托也在夏威夷作威作福，它利用 EMP 电磁脉冲让电子设备失灵，吞食了核潜艇的核弹，不过穆托这么做果然招引来了哥斯拉，两只怪兽开始了第一次的亲密接触。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782926426>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782926426>)
collapsed:: false  
    - #+BEGIN_QUOTE
        在此前美国的那颗孢子，感应到了雄性穆托的召唤，也跟着孵化，雌性穆托体型更为庞大，开始对拉斯维加斯进行打砸。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782930602>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782930602>)
collapsed:: false  
    - #+BEGIN_QUOTE
        两个穆托在旧金山汇合，雄性穆托给雌性穆托贡献出一枚超大核弹，雌性穆托也选中了旧金山作为筑巢产卵的风水宝地。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782957288>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782957288>)
collapsed:: false  
    - #+BEGIN_QUOTE
        此时哥斯拉也抵达旧金山，雌性穆托和哥斯拉开始大乱斗，显然雌性穆托很难和哥斯拉势均力敌，眼看就要败下阵来，雄性穆托加入了战斗。

三只泰坦巨兽为此展开猛烈的厮杀，哥斯拉这时背鳍发蓝，口爆出原子吐息击退雌性穆托，然后再来一招蝎子摆尾直接把雌穆托甩狗带。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782982272>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782982272>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img9.doubanio.com/view/thing_review/l/public/p5729345.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782987693>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643782987693>)
collapsed:: false  
    - #+BEGIN_QUOTE
        雌性穆托全灭军队要拿到核弹之时，哥斯拉出现再次来灭杀雌性穆托，只见哥斯拉温柔地掰开雌性穆托的嘴，直接把原子吐息送进了雌性穆托的嘴里，真好吃！好吃到爆！于是雌性穆托就裂开了。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783019478>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783019478>)
collapsed:: false  
    - #+BEGIN_QUOTE
        战胜的哥斯拉仰天长啸，不过这时它也已经精疲力竭，吼叫完后就倒下了。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783031126>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783031126>)
collapsed:: false  
    - #+BEGIN_QUOTE
        第二天清早，哥斯拉重新雄起，人类开始对哥斯拉的评价两极化，有人对它嫉妒崇拜，有人对它的出现感到威胁。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783037302>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783037302>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img1.doubanio.com/view/thing_review/l/public/p5729347.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783040233>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783040233>)
collapsed:: false  
    - #+BEGIN_QUOTE
        哥斯拉无视人类的质疑，慢悠悠游回深海。

2014 年哥斯拉事件之后，帝王组织发现，哥斯拉经常在骷髅岛和南极海域逗留。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783046810>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783046810>)
collapsed:: false  
    - #+BEGIN_QUOTE
        在这之后，帝王组织也被世人所熟知，在全球的几十个前哨站也成了被公开的秘密，帝王计划的前哨站基地，是用来观测并研究那些潜伏着的泰坦巨兽。

在全球目前一共有 26 个前哨站，被命名的就有 20 个，不过也只是用数字代号命名而已。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783065589>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783065589>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img3.doubanio.com/view/thing_review/l/public/p5729350.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783069084>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783069084>)
collapsed:: false  
    - #+BEGIN_QUOTE
        其中 2009 年，科学家就在中国云南发现了摩斯拉的神庙，然后建立了 61 号前哨站基地，这也是 2019 年《哥斯拉 2：怪兽之王》的开端。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783074005>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643783074005>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img1.doubanio.com/view/thing_review/l/public/p5729349.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796889261>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796889261>)
collapsed:: false  
    - #+BEGIN_QUOTE
        艾玛和麦迪逊住在中国云南长期研究摩斯拉 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796899081>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796899081>)
collapsed:: false  
    - #+BEGIN_QUOTE
        南极洲附近的 32 号前哨站，那里研究的对象是王者基多拉，乔纳他们把前哨站的人全部干掉，利用奥卡装置启动苏醒基多拉的模式。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796925333>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796925333>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img9.doubanio.com/view/thing_review/l/public/p5729354.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796930458>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796930458>)
collapsed:: false  
    - #+BEGIN_QUOTE
        随即基多拉苏醒被释放出来，一片混乱中人类只有仓皇而逃的份，这时候哥斯拉也现身，两只巨兽初次见面直接开杠厮打在一起。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796940923>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796940923>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img9.doubanio.com/view/thing_review/l/public/p5729355.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796944673>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796944673>)
collapsed:: false  
    - #+BEGIN_QUOTE
        帝王组织这边也是一片混乱不明状况，突然这时艾玛连线，原来她并不是人质而是一切的始作俑者。

她在经历丧子之痛后，终于悟了，她认为归根结底这是自然的报复，人口过剩和污染还有战争，造成巨兽一次次前来打扰，他们的目的是恢复大自然的平衡，巨兽破坏的地方，很快都重新恢复了绿意生机，人类其实才是地球的病毒。

所以她要释放出更多巨兽，给地球来一次大洗牌，优胜略汰，让地球重新平衡，一番慷慨激昂的演讲之后众人都呆掉。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796975724>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796975724>)
collapsed:: false  
    - #+BEGIN_QUOTE
        接着就是艾玛的计划，她释放了莫纳岛火山的巨鸟拉顿，拉顿所飞之处变成一片废墟。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796986222>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796986222>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img1.doubanio.com/view/thing_review/l/public/p5729357.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796989881>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643796989881>)
collapsed:: false  
    - #+BEGIN_QUOTE
        基多拉出现，二话不说两巨兽又干在了一起，不下三招拉顿就被干趴下，而这时哥斯拉又从海里冒出，继续要和基多拉再干一回。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797003990>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797003990>)
collapsed:: false  
    - #+BEGIN_QUOTE
        就在两只巨兽在海里干仗之时，军方又想借机利用新武器” 水中氧气破坏者 “，一箭双雕干掉基多拉和哥斯拉。

炸弹投掷之后，产生巨大威力，遗憾的是基多拉在爆炸中逃离，而哥斯拉被炸得元气大伤沉入到深海，人类感应到哥斯拉心跳停止，认为它可能死了。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797024897>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797024897>)
collapsed:: false  
    - #+BEGIN_QUOTE
        另一边基多拉也通过吼叫释放频率，苏醒了更多长眠在地球的泰坦巨兽，并要求这些巨兽听从于它的召唤和指挥，最先过来跪舔的，就是刚败北的拉顿。

在中国云南这边，摩斯拉也破茧成蝶 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797043895>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797043895>)
collapsed:: false  
    - #+BEGIN_QUOTE
        闪着金光的摩斯拉出现在前哨站，并煽动翅膀把光粒子撒入海中替哥斯拉疗伤。

原来在远古时期，哥斯拉是怪兽之王，摩斯拉是怪兽女王，两者有着共生的关系，也就是这时，哥斯拉有了心跳但还是伤得不轻。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797070327>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797070327>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img9.doubanio.com/view/thing_review/l/public/p5729364.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797075760>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797075760>)
collapsed:: false  
    - #+BEGIN_QUOTE
        于是芹泽跟着哥斯拉踪迹，去到海底的亚特兰蒂斯国，这个前面也聊过了不多展开。

芹泽在祭坛上找到了哥斯拉，他毫不犹豫启动了核弹，湮灭在巨大的核爆炸中，而哥斯拉遇核重生，还是吃得很撑的那种，体型又重新胖了一大圈，即使没有敌人，能量还多到不得不对天空来一下口爆原子吐息自 high。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797092495>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797092495>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img9.doubanio.com/view/thing_review/l/public/p5729365.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797095537>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797095537>)
collapsed:: false  
    - #+BEGIN_QUOTE
        哥斯拉这时出现在这，要和基多拉再战第三回合！

而且哥斯拉女伴摩斯拉也出现加入战斗，拉顿这时也出现，和摩斯拉对战，基多拉这时爆出大重力射线，搞得哥斯拉有点招架不住，摩斯拉这边险胜拉顿但自己也伤得不轻。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797108659>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797108659>)
collapsed:: false  
    - #+BEGIN_QUOTE
        基多拉见状直接把哥斯拉抓上天，来了个万米自由落地，哥斯拉直接变成火球坠入地面再次奄奄一息。

就在基多拉想要对哥斯拉最后射出重力射线彻底秒了哥斯拉时，女友摩斯拉为爱档射线，壮烈牺牲，摩斯拉死后的能量正好依附到了哥斯拉身上，哥斯拉又加持了一道能量，开始进化红莲状态爆补。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797122529>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797122529>)
collapsed:: false  
    - #+BEGIN_QUOTE
        红莲哥斯拉很快苏醒，仅仅释放第一招能量波就烧毁了基多拉两颗龙头，接着就是完虐基多拉时候，该吃吃该烧烧，原子吐息直接让基多拉灰飞烟灭。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797139410>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797139410>)
collapsed:: false  
    - #+BEGIN_QUOTE
        大战结束后，众多泰坦巨兽重新跪倒在哥斯拉的石榴裙尾下，拉顿也不例外。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797145585>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797145585>)
collapsed:: false  
    - #+BEGIN_QUOTE
        ![](https://img3.doubanio.com/view/thing_review/l/public/p5729370.webp) 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797148809>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797148809>)
collapsed:: false  
    - #+BEGIN_QUOTE
        在最后的新闻报道中，帝王组织发现了摩斯拉的一枚卵，这也说明摩斯拉在大战前给自己留了个种。 
        #+END_QUOTE
        collapsed:: true  
        - Note
            -  
        - Tags
            - 
        - External reference
            - 
        - Association
           - #+BEGIN_QUOTE
            
             #+END_QUOTE
         - [内部链接](<http://localhost:7026/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797154741>) |  [外部链接](<https://simpread.pro/@kenshin/reading/2292?title=怪兽宇宙时间线大盘点#id=1643797154741>)
